#include "Camera.h"

Camera::Camera(int width, int height)
{
	this->width = width;
	this->height = height;
}

void Camera::Matrix(glm::vec3 position, glm::vec3 orientation, float nearPlane, float farPlane, GLuint shader)
{
	glm::mat4 view = glm::mat4(1.0f);
	glm::mat4 proj = glm::mat4(1.0f);

	view = glm::lookAt(position, position + orientation, up);
	proj = glm::perspective(glm::radians(FOV/2.0f), (float)width / (float)height, nearPlane, farPlane);

	glUniformMatrix4fv(glGetUniformLocation(shader, "camMatrix"), 1, GL_FALSE, glm::value_ptr(proj * view));
}
