#include "Octree.h"

Octree::Octree()
{
	nodes = {};
	nodes.reserve(2048);
	AddNode(7, {0,0,0});
}

size_t Octree::Get(const glm::ivec3 position, uint32_t startIndex)
{
	OctreeNode& node = nodes[startIndex];

	if (node.isLeaf)
	{
		return startIndex;
	}

	int childIndex = SegmentOctant(position >> (int32_t)(node.level-1));
	uint32_t childNodeIndex = node.childrenOffset + childIndex;
	return Get(position, childNodeIndex);
}

void Octree::Split(uint32_t index)
{
	OctreeNode& node = nodes[index];

	if (node.level == 0) { return; }
	
	node.isLeaf = false;

	node.childrenOffset = AddNode(node.level - 1, node.offset + (glm::uvec3(octreeOffsets[0]) << (uint32_t)(node.level-1)));
	for (int i = 1; i < 8; i++)
	{
		AddNode(node.level - 1, node.offset + (glm::uvec3(octreeOffsets[i]) << (uint32_t)(node.level-1)));
	}
}

void Octree::ForceMerge(uint32_t nodeIndex)
{
	OctreeNode& node = nodes[nodeIndex];

	if (node.isLeaf)
	{
		return;
	}

	node.isLeaf = true;

	for (int i = 0; i < 8; i++)
	{
		ForceMerge(node.childrenOffset + i);
	}

	for (int i = 0; i < 8; i++)
	{
		freedIndices.push(node.childrenOffset + i);
	}
	node.childrenOffset = 0;
	node.childMask = 0;
	node.isLeaf = true;

}

bool Octree::TryMerge(uint32_t nodeIndex)
{
	OctreeNode& node = nodes[nodeIndex];

	if (node.isLeaf)
	{
		return true;
	}

	bool canMerge = true;
	for (int i = 0; i < 8; i++)
	{
		canMerge &= nodes[node.childrenOffset + i].isLeaf;
	}

	if (!canMerge) return false;

	for (int i = 0; i < 8; i++)
	{
		freedIndices.push(node.childrenOffset+i);
	}
	
	node.childrenOffset = 0;
	node.childMask = 0;
	node.isLeaf = true;

	return true;
}

uint32_t Octree::SegmentOctant(glm::ivec3 localPos)
{
	uint32_t code = 0;
	if (localPos.z % 2 >= 1) code |= 4;
	if (localPos.y % 2 >= 1) code |= 2;
	if (localPos.x % 2 >= 1) code |= 1;
	return code;
}

uint32_t Octree::AddNode(uint8_t level, glm::ivec3 offset)
{
	if (freedIndices.empty()) {
		nodes.push_back(OctreeNode{ 0, true, offset, level, 0 });
		return nodes.size() - 1;
	}
	else
	{
		uint32_t idx = freedIndices.front();
		nodes[idx] = OctreeNode{0, true, offset, level, 0};
		freedIndices.pop();
		return idx;
	}

}
