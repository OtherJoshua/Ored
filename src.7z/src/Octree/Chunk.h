#pragma once

#include <cstdint>
#include <glm/glm.hpp>
#include <array>
#include <memory>

#include "../World/Voxel.h"

class Chunk
{
public:
	Chunk();
	Chunk(const Chunk&) = delete;
	Chunk(Chunk&& other) noexcept
		: data(std::move(other.data)), level(other.level), isLoaded(other.isLoaded), chunkPosition(other.chunkPosition) {}

	~Chunk();

	Chunk& operator=(Chunk&& other) noexcept {
		if (this != &other) {
			data = std::move(other.data);
		}
		return *this;
	}

	Chunk& operator=(const Chunk&) = delete;

	void Set(uint32_t x, uint32_t y, uint32_t z, Voxel voxel);
	Voxel& Get(uint32_t x, uint32_t y, uint32_t z);

	static const int CHUNKSIZE = 32;

	bool isLoaded;
	int level;

	glm::ivec3 chunkPosition;

	static int chunk_memory_unit;

private:
	std::unique_ptr<Voxel[]> data;
};

