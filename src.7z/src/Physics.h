#pragma once

#include <glm/glm.hpp>
#include <array>
#include <unordered_set>
#include <tuple>

namespace Physics
{
	const float EPSILON = 0.0001f;

	struct Triangle
	{
		int v1, v2, v3;

		Triangle(int v1, int v2, int v3) : v1(v1), v2(v2), v3(v3) {};

		bool operator==(const Triangle& other) const {
			return v1 == other.v1 && v2 == other.v2 && v3 == other.v3;
		}
	};

	struct Edge
	{
		int v1, v2;

		Edge(int a, int b) : v1(std::min(a, b)), v2(std::max(a, b)) {}

		bool operator==(const Edge& other) const {
			return v1 == other.v1 && v2 == other.v2;
		}
	};

	struct CollisionMesh
	{
		std::vector<glm::vec3> vertices;
		std::vector<Triangle> tris;
		std::vector<Edge> edges;

		void RecalculateFaces();
		void RecalculateEdges();
	};

	struct Ray {
		glm::vec3 origin;
		glm::vec3 direction;
	};

	struct Capsule {
		glm::vec3 a;
		glm::vec3 b;
		float radius;
	};

	struct Box {
		glm::vec3 pos;
		glm::vec3 size;
	};

	struct RayResult
	{
		bool hit;
		float t;
		glm::vec3 normal;
	};

	glm::vec3 ProjectToPlane(glm::vec3 point, glm::vec3 normal);

	static RayResult RayTriangle(const Ray& ray, const glm::vec3& v1, const glm::vec3& v2, const glm::vec3& v3);
	static RayResult RayCapsule(const Ray& ray, const Capsule& capsule);
	RayResult RayBox(const Ray& ray, const Box& box);

	static RayResult RayMesh(const Ray& ray, const CollisionMesh& mesh);
	RayResult SphereMesh(const Ray& ray, float radius, const CollisionMesh& mesh);
}

namespace std {
	template <> struct hash<Physics::Edge> {
		size_t operator()(const Physics::Edge& e) const {
			return hash<int>()(e.v1) ^ hash<int>()(e.v2);
		}
	};
	template <> struct hash<Physics::Triangle> {
		size_t operator()(const Physics::Triangle& e) const {
			return hash<int>()(e.v1) ^ hash<int>()(e.v2) ^ hash<int>()(e.v3);
		}
	};
}


