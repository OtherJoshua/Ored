#include "ChunkMeshBuilder.h"

#include "OctreeManager.h"

ChunkMeshBuilder::ChunkMeshBuilder()
{
	this->activeOctreeManager = nullptr;
	this->activeMesh = nullptr;
}

void ChunkMeshBuilder::BuildMesh(Chunk* chunk, ChunkMesh* mesh)
{
	//glm::vec3 chunkPos = chunk.getGlobalPosition() * Chunk::CHUNK_SIZE;

	activeChunk = chunk;
	activeMesh = mesh;

	for (int y = 0; y < Chunk::CHUNKSIZE; y++)
	{
		for (int z = 0; z < Chunk::CHUNKSIZE; z++)
		{
			for (int x = 0; x < Chunk::CHUNKSIZE; x++)
			{
				Voxel& voxel = activeChunk->Get(x, y, z);

				if (voxel.type == VoxelType::NONE) continue;

				BuildFace(northFace, { voxelData[voxel.type].texCoordSide }, {x, y, z}, VoxelFace::NORTH);
				BuildFace(southFace, { voxelData[voxel.type].texCoordSide }, { x, y, z }, VoxelFace::SOUTH);
				BuildFace(eastFace, { voxelData[voxel.type].texCoordSide }, { x, y, z },  VoxelFace::EAST);
				BuildFace(westFace, { voxelData[voxel.type].texCoordSide }, { x, y, z },  VoxelFace::WEST);

				BuildFace(upFace, { voxelData[voxel.type].texCoordTop }, { x, y, z }, VoxelFace::UP);
				BuildFace(downFace, { voxelData[voxel.type].texCoordBottom }, { x, y, z }, VoxelFace::DOWN);
			}
		}
	}

	activeMesh->mesh.bytes = activeMesh->mesh.vertexPositions.size() * sizeof(GLfloat) + activeMesh->mesh.texturePositions.size() * sizeof(GLfloat) + activeMesh->mesh.normals.size() * sizeof(GLfloat) + activeMesh->mesh.indices.size() * sizeof(GLuint);

	activeMesh = nullptr;

	//std::cout << "Finished Meshing Octree, t=" << t << std::endl;
}

void ChunkMeshBuilder::BuildFace(const std::array<GLfloat, 12>& faceVertices, const glm::vec2& texCoords, const glm::ivec3& voxelPos, VoxelFace face)
{
	glm::ivec3 otherPos = voxelPos + positionOffsets[face];

	//check for oob

	Voxel otherVoxel; //TODO: dont copy this in case it has extra data or something
	if (otherPos.x < 0 || otherPos.y < 0 || otherPos.z < 0 || otherPos.x >= Chunk::CHUNKSIZE || otherPos.y >= Chunk::CHUNKSIZE || otherPos.z >= Chunk::CHUNKSIZE)
	{
		otherVoxel = {VoxelType::NONE};
	}
	else
	{
		otherVoxel = activeChunk->Get(otherPos.x, otherPos.y, otherPos.z);
	}
	
	if((otherVoxel.type == VoxelType::NONE))
	{
		activeMesh->AddFace(faceVertices, activeOctreeManager->getAtlas()->GetUVArray(texCoords.x, texCoords.y), positionOffsets[face], voxelPos);
		//octree->faces++; TODO: face count
	}
	
}
