#pragma once

#include "../Render/Shader.h"
#include "../Render/Camera.h"

#include "../Render/TextureAtlas.h"
#include <mutex>
#include <queue>

#include "Octree.h"
#include "ChunkMeshBuilder.h"

#include <stack>
#include <algorithm>

#include <memory>
#include <unordered_map>

#include "../Physics.h"

//TODO: Dont store the mesh, just buffer it and store the model
//TODO: When building the mesh, don't duplicate indices
struct ChunkMesh
{
	Mesh mesh;
	Model model;

	glm::vec3 position;

	bool safe = false;

	void Buffer() {
		if (mesh.vertexPositions.size() == 0) return;

		model.AddData(mesh);
	}
	void Clear() {
		mesh.vertexPositions.clear();
		mesh.vertexPositions.shrink_to_fit();

		mesh.texturePositions.clear();
		mesh.texturePositions.shrink_to_fit();

		mesh.normals.clear();
		mesh.normals.shrink_to_fit();

		mesh.indices.clear();
		mesh.indices.shrink_to_fit();

		mesh.bytes = 0;

		vertexCount = 0;
	}

	void AddFace(const std::array<GLfloat, 12>& face, const std::array<GLfloat, 8>& texCoords, const glm::vec3& normal, const glm::ivec3& voxelPos);
	uint32_t vertexCount = 0;
};

struct ManagerStats
{
	size_t chunkCount;
	size_t octreeSize;
	size_t octreeFreed;

	size_t chunkLoadQueueSize;
	size_t chunkMeshQueueSize;
	size_t chunkBufferQueueSize;

	uint64_t meshBytes;

	uint64_t lastT = 0;
};

struct RayHitData
{
	bool didHit;
	float octDist;
	float chunkDist;
	glm::vec3 hitNormal;
	glm::ivec3 hitPos;
	uint32_t rayOctantIdx;
};

struct ChunkRayData
{
	float dist;
	glm::vec3 normal;
	glm::ivec3 hitPos;
};

class OctreeManager
{
public:
	OctreeManager();
	~OctreeManager();

	void UpdateCameraPosition(const glm::vec3 cameraPosition);
	void BufferMeshes();
	void Render(Camera* camera, ShaderProgram* shader);

	const std::unique_ptr<TextureAtlas>& getAtlas() const { return atlas; };

	const ManagerStats& getStats() const { return stats; }

	float lodC = 1.0f;
	bool pauseOctreeUpdates = false;

	RayHitData RaycastVolume(glm::vec3 origin, glm::vec3 dir);
	ChunkRayData RaycastChunk(glm::vec3 origin, glm::vec3 dir, size_t chunkIdx);

	Physics::RayResult SphereCast(glm::vec3 offset, float radius, glm::vec3 direction, float maxDist);

	void SetVoxel(glm::ivec3 offset, Voxel voxel);
	Voxel GetVoxel(glm::ivec3 offset);

private:
	void UpdateChunks();
	void LoadChunks();
	void MeshChunks();

	void CreateChunk(uint32_t id);
	void DeleteChunk(uint32_t id);

	Chunk* GetChunkFromID(uint32_t id);
	ChunkMesh& GetMeshFromID(uint32_t id);
	Physics::CollisionMesh& GetCollisionMeshFromID(uint32_t id);

	ManagerStats stats;

	//Assets
	Octree octree;
	std::unique_ptr<TextureAtlas> atlas;
	ChunkMeshBuilder builder;

	//Chunk Handling
	std::queue<uint32_t> chunkLoadQueue;

	std::deque<uint32_t> chunkMeshQueue;
	std::queue<uint32_t> chunkBufferQueue;

	std::unordered_map<uint32_t, size_t> chunkIdMap;

	std::vector<std::unique_ptr<Chunk>> chunks;
	std::vector<ChunkMesh> meshes;
	std::vector<Physics::CollisionMesh> collisionMeshes;

	//std::vector<Chunk> chunks;
	//std::vector<ChunkMesh> chunkMeshes;

	std::mutex chunkMutex;
	std::mutex cameraMutex;

	//Threading
	std::thread workerThread;
	std::atomic<bool> workerRunning;
	glm::vec3 savedCameraPosition;

	void workerFunction();
};

