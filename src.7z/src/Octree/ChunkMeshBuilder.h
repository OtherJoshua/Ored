#pragma once

#include <array>
#include <stack>
#include <iostream>

#include "Octree.h"
#include "Chunk.h"

#include "../Render/Model.h"

class OctreeManager;
struct ChunkMesh;

namespace {
	const std::array<GLfloat, 12> northFace = { //0, 1, 2, 3
		0,0,0, 0,1,0, 1,1,0, 1,0,0
	};
	const std::array<GLfloat, 12> southFace = { // 7, 6, 5, 4
		1,0,1, 1,1,1, 0,1,1, 0,0,1
	};

	const std::array<GLfloat, 12> eastFace = { //3, 2, 6, 7
		1,0,0, 1,1,0, 1,1,1, 1,0,1
	};
	const std::array<GLfloat, 12> westFace = { //4, 5, 1, 0
		0,0,1, 0,1,1, 0,1,0, 0,0,0
	};


	const std::array<GLfloat, 12> upFace = { //1, 5, 6, 2
		0,1,0, 0,1,1, 1,1,1, 1,1,0
	};
	const std::array<GLfloat, 12> downFace = { //4, 0, 3, 7
		0,0,1, 0,0,0, 1,0,0, 1,0,1
	};
}

const std::array<glm::ivec3, 6> positionOffsets{
	glm::ivec3(0, 0, -1),
	glm::ivec3(0, 0, 1),

	glm::ivec3(1, 0, 0),
	glm::ivec3(-1, 0, 0),

	glm::ivec3(0, 1, 0),
	glm::ivec3(0, -1, 0),
};

class ChunkMeshBuilder
{
public:
	ChunkMeshBuilder();

	void BuildMesh(Chunk* chunk, ChunkMesh* mesh);

	void SetActiveManager(OctreeManager* manager) { activeOctreeManager = manager; }
	
private:
	void BuildFace(const std::array<GLfloat, 12>& faceVertices, const glm::vec2& texCoords, const glm::ivec3& voxelPos, VoxelFace face);

	OctreeManager* activeOctreeManager;
	Chunk* activeChunk;
	ChunkMesh* activeMesh;
};

