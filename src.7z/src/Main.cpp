#include <iostream>

#include "Application.h"

#define STB_IMAGE_IMPLEMENTATION
#include "../stb_image.h"

int main(int argc, char* argv[])
{
	Application app = Application();
	app.Run();

	return 0;
}