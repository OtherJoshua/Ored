#include "Shader.h"

std::string get_file_contents(const char* filename)
{
	std::ifstream in(filename, std::ios::binary);
	if (in)
	{
		std::string contents;
		in.seekg(0, std::ios::end);
		contents.resize(in.tellg());
		in.seekg(0, std::ios::beg);
		in.read(&contents[0], contents.size());
		in.close();
		return(contents);
	}
	throw(errno);
}

ShaderInstance::ShaderInstance(const std::string source, const GLenum shaderType)
{
	const char* sourceChar = source.c_str();

	instance = glCreateShader(shaderType);
	glShaderSource(instance, 1, &sourceChar, NULL);
	glCompileShader(instance);

	int success;
	char infoLog[512];
	glGetShaderiv(instance, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(instance, 512, NULL, infoLog);
		std::cout << "ERR - Shader failed to compile\n" << infoLog << std::endl;
	}
}

ShaderInstance::~ShaderInstance()
{
	glDeleteShader(instance);
}

void ShaderInstance::Attach(GLuint program) const
{
	glAttachShader(program, instance);
}

ShaderProgram::ShaderProgram(const ShaderInstance& instance)
{
	program = glCreateProgram();

	instance.Attach(program);

	glLinkProgram(program);

	int success;
	char infoLog[512];
	glGetProgramiv(program, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(program, 512, NULL, infoLog);
		std::cout << "ERR - Shader failed to link\n" << infoLog << std::endl;
	}
}

ShaderProgram::ShaderProgram(const ShaderInstance& instanceA, const ShaderInstance& instanceB)
{
	program = glCreateProgram();

	instanceA.Attach(program);
	instanceB.Attach(program);

	glLinkProgram(program);

	int success;
	char infoLog[512];
	glGetProgramiv(program, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(program, 512, NULL, infoLog);
		std::cout << "ERR - Shader failed to link\n" << infoLog << std::endl;
	}
}

ShaderProgram::~ShaderProgram()
{
	glDeleteProgram(program);
}

void ShaderProgram::Use()
{
	glUseProgram(program);
}

GLuint ShaderProgram::getId()
{
	return program;
}

GLuint ShaderProgram::ShaderLocation(std::string name)
{
	return glGetUniformLocation(program, name.c_str());
}
