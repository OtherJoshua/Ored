#pragma once

#include "GameStateBase.h"

#include <SDL3/SDL.h>

#include "../../imgui/imgui.h"
#include "../../imgui/imgui_impl_sdl3.h"
#include "../../imgui/imgui_impl_opengl3.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "Player.h"

#include <chrono>

namespace GameState
{
	class GameStateWorld : public GameStateBase
	{
	public:
		GameStateWorld(Application* app);
		~GameStateWorld();

		void Update(double deltaTime);
		void Event(SDL_Event event);

		void HandlePlayer(double deltaTime);

		void GUI();

		OctreeManager* GetOctreeManager() { return manager.get(); }
		bool isMouseCaptured() { return mouseCaptured; }

		VoxelType voxelTypeSelect;

		double dt = 0;
		uint64_t t;
		float physicsTime = 0.0f;

	private:
		std::unique_ptr<Camera> camera;
		std::unique_ptr<OctreeManager> manager;
		std::shared_ptr<ShaderProgram> shader;

		Player* player;

		bool mouseCaptured;
	};
}


