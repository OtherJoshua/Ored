#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <glm/glm.hpp>

enum VoxelType
{
	NONE,
	GRASS,
	DIRT,
	STONE,
	COBBLESTONE,
	SAND,
	LOG,
	LEAVES,
	WATER,

	MAX_VOXEL_TYPE
};

enum VoxelFace
{
	NORTH,
	SOUTH,
	EAST,
	WEST,
	UP,
	DOWN
};

struct VoxelData
{
	std::string name;
	glm::vec2 texCoordTop;
	glm::vec2 texCoordSide;
	glm::vec2 texCoordBottom;
	bool translucent;
};

static std::array<VoxelData, MAX_VOXEL_TYPE> voxelData = {
	VoxelData{"Air", { -1, -1}, {-1, -1}, {-1, -1}, true},
	VoxelData{"Grass", { 0, 0}, {3, 0}, {2, 0}, false},
	VoxelData{"Dirt", { 2, 0}, {2, 0}, {2, 0}, false},
	VoxelData{"Stone", { 1, 0}, {1, 0}, {1, 0}, false},
	VoxelData{"Cobble", { 0, 1}, {0, 1}, {0, 1}, false},
	VoxelData{"Sand", { 2, 1}, {2, 1}, {2, 1}, false},
	VoxelData{"Log", { 5, 1}, {4, 1}, {5, 1}, false},
	VoxelData{"Leaves", { 6, 3}, {6, 3}, {6, 3}, false},
	VoxelData{"Water", { 13, 12}, {13, 12}, {13, 12}, true},
};

struct Voxel
{
	VoxelType type;
};