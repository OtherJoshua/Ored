#pragma once

#include <glm/glm.hpp>
#include "GameStateBase.h"
#include "../Physics.h"

namespace GameState
{
	class GameStateWorld;
}


//TODO: Player should be a subclass of entity?
class Player
{
public:
	Player(GameState::GameStateWorld* state);

	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 orientation;

	const glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f);

	void Update(double deltaTime);
	void Event(SDL_Event event);

	glm::vec3 MoveAndSlide(glm::vec3 velocity, int depth);

	float speed = 10.0f;
	float radius = 0.5f;

private:
	float sensitivity = 0.1f;
	const int MAX_BOUNCES = 4;
	const float SKIN_WIDTH = 0.001f;

	GameState::GameStateWorld* state;
};

