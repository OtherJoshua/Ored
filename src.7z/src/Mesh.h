#pragma once

#include <vector>
#include <glad/glad.h>

struct Mesh
{
	std::vector<GLfloat> vertexPositions;
	std::vector<GLfloat> texturePositions;
	std::vector<GLfloat> normals;
	std::vector<GLuint> indices;

	size_t bytes;
};

