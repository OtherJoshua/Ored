#pragma once

#include "../Mesh.h"

class Model
{
public:
	Model() = default;
	Model(const Mesh& mesh);
	~Model();

	void AddData(const Mesh& mesh);
	void DeleteData();

	int getIndicesCount() const;
	bool isBuffered() const;

	void Draw() const;

private:
	void GenVAO();
	void AddEBO(const std::vector<GLuint>& indices);
	void AddVBO(int dimensions, const std::vector<GLfloat>& data);
	void BindVAO();

	GLuint vao = 0;
	int indexCount = 0;

	int vboCount = 0;
	std::vector<GLuint> buffers;
};

