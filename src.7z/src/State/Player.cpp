#include "Player.h"

#include "GameStateWorld.h"

Player::Player(GameState::GameStateWorld* state)
{
	this->state = state;

	this->position = glm::vec3(0, 0, 0);
	this->velocity = glm::vec3(0, 0, 0);
	this->orientation = glm::vec3(0, 0, -1);
}

void Player::Update(double deltaTime)
{
	const bool* keyState = SDL_GetKeyboardState(NULL);

	velocity = glm::vec3(0, 0, 0);

	// Handles key inputs
	if (keyState[SDL_SCANCODE_W])
	{
		velocity += speed * orientation;
	}
	if (keyState[SDL_SCANCODE_A])
	{
		velocity += speed * -glm::normalize(glm::cross(orientation, up));
	}
	if (keyState[SDL_SCANCODE_S])
	{
		velocity += speed * -orientation;
	}
	if (keyState[SDL_SCANCODE_D])
	{
		velocity += speed * glm::normalize(glm::cross(orientation, up));
	}

	if (keyState[SDL_SCANCODE_SPACE]) //TODO: is_on_floor() method
	{
		velocity += speed * up;
	}

	if (keyState[SDL_SCANCODE_LSHIFT])
	{
		velocity += speed * -up;
	}

	if (keyState[SDL_SCANCODE_R])
	{
		this->position = glm::vec3(2048, 3080, 2048);
		velocity = glm::vec3(0, 0, 0);
	}

	glm::vec3 ms = MoveAndSlide(velocity * (float)deltaTime, 0);
	position += ms;
	if (glm::length2(position) > (4096 * 4096 * 4)) {
		std::cout << position.x << "," << position.y << "," << position.z << "\n";
	}
	

	//position += velocity * (float)deltaTime;
}

void Player::Event(SDL_Event event)
{
	switch (event.type)
	{
	case SDL_EVENT_MOUSE_MOTION:
		if (state->isMouseCaptured())
		{
			float rotX = event.motion.yrel * sensitivity;
			float rotY = event.motion.xrel * sensitivity;

			// Calculates upcoming vertical change in the Orientation
			glm::vec3 newOrientation = glm::rotate(orientation, glm::radians(-rotX), glm::normalize(glm::cross(orientation, up)));

			// Decides whether or not the next vertical Orientation is legal or not
			if (abs(glm::angle(newOrientation, up) - glm::radians(90.0f)) <= glm::radians(85.0f))
			{
				orientation = newOrientation;
			}

			// Rotates the Orientation left and right
			orientation = glm::rotate(orientation, glm::radians(-rotY), up);
		}
		break;

	case SDL_EVENT_MOUSE_BUTTON_DOWN:
		if (event.button.button == SDL_BUTTON_LEFT && state->isMouseCaptured())
		{
			RayHitData rhd = state->GetOctreeManager()->RaycastVolume(position, glm::normalize(orientation));
			if (rhd.didHit)
			{
				state->GetOctreeManager()->SetVoxel(rhd.hitPos, Voxel{ VoxelType::NONE });
			}
		}
		else if (event.button.button == SDL_BUTTON_RIGHT && state->isMouseCaptured())
		{
			RayHitData rhd = state->GetOctreeManager()->RaycastVolume(position, glm::normalize(orientation));
			if (rhd.didHit)
			{
				glm::ivec3 newPosition = rhd.hitPos + glm::ivec3(rhd.hitNormal);
				state->GetOctreeManager()->SetVoxel(newPosition, Voxel{ state->voxelTypeSelect });
			}
		}
		break;
	}
}

glm::vec3 Player::MoveAndSlide(glm::vec3 velocity, int depth)
{
	if (depth >= MAX_BOUNCES) {
		return glm::vec3(0.0f);
	}

	if (glm::length2(velocity) < (Physics::EPSILON*Physics::EPSILON)) { return velocity; }

	float dist = glm::length(velocity) + SKIN_WIDTH;
	std::cout << velocity.x << "," << velocity.y << "," << velocity.z << "\n";
	Physics::RayResult res = state->GetOctreeManager()->SphereCast(position, radius - SKIN_WIDTH, glm::normalize(velocity), dist);
	if (res.hit) {
		glm::vec3 snapToSurface = glm::normalize(velocity) * glm::max((res.t) - SKIN_WIDTH, 0.0f);
		glm::vec3 leftover = velocity - snapToSurface;

		if (glm::length(snapToSurface) <= SKIN_WIDTH) {
			snapToSurface = glm::vec3(0.0f);
		}

		float mag = glm::length(leftover);
		glm::vec3 proj = Physics::ProjectToPlane(leftover, res.normal);
		if (mag > Physics::EPSILON && glm::length2(proj) > Physics::EPSILON) {
			leftover = glm::normalize(proj) * mag;
		} else {
			leftover = glm::vec3(0.0f);
		}

		return snapToSurface + MoveAndSlide(leftover, depth + 1);
	}

	return velocity;
}
