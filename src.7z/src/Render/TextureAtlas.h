#pragma once

#include "Texture.h"

#include <glm/glm.hpp>
#include <array>

class TextureAtlas : public Texture
{
public:
	TextureAtlas(const char* filepath, int countX, int countY);

	glm::vec2 GetUV(int x, int y) const;
	std::array<GLfloat, 8> GetUVArray(int x, int y) const;

private:
	int countX, countY;
	double unitX, unitY;

};

