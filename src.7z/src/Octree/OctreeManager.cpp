#include "OctreeManager.h"

OctreeManager::OctreeManager()
	: octree()
{
	atlas = std::make_unique<TextureAtlas>("res/atlas.png", 16, 16);
	workerThread = std::thread(&OctreeManager::workerFunction, this);
	workerRunning = true;

	builder = ChunkMeshBuilder();
	builder.SetActiveManager(this);

	savedCameraPosition = {};

	//chunks = {};
	//meshes = {};
	chunkIdMap = {};

	CreateChunk(0);
}

OctreeManager::~OctreeManager()
{
	workerRunning = false;
	if (workerThread.joinable()) {
		workerThread.join();
	}
}

void OctreeManager::UpdateCameraPosition(const glm::vec3 cameraPosition)
{
	{
		std::lock_guard<std::mutex> lock(cameraMutex);
		this->savedCameraPosition = cameraPosition;
	}
}

void OctreeManager::BufferMeshes()
{
	if (chunkBufferQueue.empty()) { return; }

	uint32_t chunkId = chunkBufferQueue.front();
	chunkBufferQueue.pop();

	std::lock_guard<std::mutex> lock(chunkMutex);

	if (chunkIdMap.find(chunkId) == chunkIdMap.end()) { return; }

	if (GetMeshFromID(chunkId).mesh.bytes > 0)
	{
		GetMeshFromID(chunkId).Buffer();
		stats.meshBytes -= GetMeshFromID(chunkId).mesh.bytes;
		GetMeshFromID(chunkId).Clear();
	}
	GetMeshFromID(chunkId).safe = true;
	
}

void OctreeManager::Render(Camera* camera, ShaderProgram* shader)
{
	shader->Use();

	GLuint texUniform = glGetUniformLocation(shader->getId(), "tex0");
	glUniform1i(texUniform, 0);
	glBindTexture(GL_TEXTURE_2D, atlas->getId());

	glm::vec3 sunDir = glm::normalize(glm::vec3(-1, -1, -1));
	glUniform3fv(shader->ShaderLocation("sunDir"), 1, glm::value_ptr(sunDir));


	std::lock_guard<std::mutex> lock(chunkMutex);

	for (auto& it : chunkIdMap)
	{
		//std::cout << "\nid:" << it.first;
		if (it.second >= chunks.size()) continue;

		Chunk* c = chunks.at(it.second).get();
		ChunkMesh& cm = meshes.at(it.second);

		if (!cm.model.isBuffered()) continue;

		OctreeNode& node = octree.getNodes()[it.first];
		bool skipMesh = false;

		//std::cout << " leaf:" << node.isLeaf << " childoffset:" << node.childrenOffset;

		if ((!node.isLeaf) && (node.childrenOffset != 0) && (chunkIdMap.find(node.childrenOffset+7) != chunkIdMap.end()))
		{
			skipMesh = true;
			//std::cout << " children:{";
			
			for (int i = 0; i < 8; i++)
			{
				bool b = GetMeshFromID(node.childrenOffset + i).safe;
				skipMesh &= b;
				//std::cout << (b ? "true," : "false,");
			}
			
			//std::cout << "} skipped:" << (skipMesh ? "true" : "false");
		}
		

		if (skipMesh) { continue; }

		glm::vec3 meshPos = cm.position * (float)Chunk::CHUNKSIZE;
		glm::mat4 model = glm::mat4(1.0f);

		model = glm::translate(model, meshPos);
		model = glm::scale(model, glm::vec3(1 << c->level));
		glUniformMatrix4fv(shader->ShaderLocation("model"), 1, GL_FALSE, glm::value_ptr(model));
		glUniform1f(shader->ShaderLocation("alpha"), 1);

		cm.model.Draw();
	}

	stats.chunkCount = chunkIdMap.size();
	stats.octreeSize = octree.getNodes().size();
	stats.octreeFreed = octree.getFreed().size();

	stats.chunkLoadQueueSize = chunkLoadQueue.size();
	stats.chunkMeshQueueSize = chunkMeshQueue.size();
	stats.chunkBufferQueueSize = chunkBufferQueue.size();
}

int lodFunc(float dist, float c)
{
	return dist != 0 ? int(std::max(0.0f, std::log2(dist-c))) : 0;
}

RayHitData OctreeManager::RaycastVolume(glm::vec3 origin, glm::vec3 dir)
{
	std::lock_guard<std::mutex> lock(chunkMutex);
	//TODO: fix issues with floating point numbers, the dist value and the bias
	float bias = 0.001;

	bool didHit = false;
	uint64_t checks = 0;

	std::stack<uint32_t> stack;
	stack.push(0);

	std::vector<OctreeNode>& nodes = octree.getNodes();

	uint32_t level = nodes[0].level;
	uint32_t maxScale = 1 << level;

	float t = 0.0f;

	glm::vec3 rayOrigin = abs(origin) / (float)Chunk::CHUNKSIZE; //local offset (scaled 1 = 1 chunk)
	glm::vec3 rayDelta = 1.0f/dir;

	glm::ivec3 stp = glm::ivec3(sign(dir));
	glm::bvec3 sgn = glm::bvec3(stp.x < 0, stp.y < 0, stp.z < 0);

	glm::vec3 rayEnd = rayOrigin + (dir * bias); //local offset (scaled 1 = 1 chunk)
	glm::uvec3 cellCheck = glm::uvec3(rayEnd) >> level; //specifies the octant coord on this level (1 = 1 octant)

	glm::vec3 normal = glm::vec3(0,0,0);

	std::function<glm::vec4()> nextDist = [&]()
		{
			glm::vec3 cellNext = (glm::vec3((glm::ivec3(cellCheck) + glm::ivec3(glm::not_(sgn))) << (int)level) - rayOrigin) * rayDelta;

			float smallest;
			glm::vec3 n;

			if (cellNext.x < cellNext.y)
			{
				if (cellNext.x < cellNext.z) {
					smallest = cellNext.x;
					n = glm::vec3(1, 0, 0) * -float((dir.x > 0) - (dir.x < 0));
				}
				else {
					smallest = cellNext.z;
					n = glm::vec3(0, 0, 1) * -float((dir.z > 0) - (dir.z < 0));
				}
			}
			else
			{
				if (cellNext.y < cellNext.z) {
					smallest = cellNext.y;
					n = glm::vec3(0, 1, 0) * -float((dir.y > 0) - (dir.y < 0));
				}
				else {
					smallest = cellNext.z;
					n = glm::vec3(0, 0, 1) * -float((dir.z > 0) - (dir.z < 0));
				}
			}

			return glm::vec4(n, smallest);
		};

	float d = -1.0f;
	ChunkRayData crd;

	while (checks < 512)
	{
		checks++;
		//std::cout << "\nrayEnd:{" << rayEnd.x << "," << rayEnd.y << "," << rayEnd.z << "} / ";
		//std::cout << "cellCheck:{" << cellCheck.x << "," << cellCheck.y << "," << cellCheck.z << "}";

		if (rayEnd.x >= maxScale || rayEnd.y >= maxScale || rayEnd.z >= maxScale || rayEnd.x < 0 || rayEnd.y < 0 || rayEnd.z < 0)
		{
			//miss
			break;
		}

		if (glm::uvec3(rayEnd) >> level != cellCheck) //Pop stack
		{
			stack.pop();
			level++;
			cellCheck >>= 1;
			continue;
		}


		if (nodes[stack.top()].isLeaf) //is leaf?
		{
			//raycast through chunk
			size_t idx = chunkIdMap[stack.top()];
			if (chunks[idx]->isLoaded)
			{
				glm::vec3 no = ( rayEnd - glm::vec3(nodes[stack.top()].offset) )*(float)Chunk::CHUNKSIZE / powf(2, level);
				//std::cout << "RayChunk:{" << no.x << "," << no.y << "," << no.z << "}";
				crd = RaycastChunk(no, dir, idx); //raycast chunk wants to take in an offset local to the chunk
				d = crd.dist * powf(2, level);
				normal = crd.normal;
				if (d >= 0)
				{
					didHit = true;
					break;
				}
			}
		}

		if (!nodes[stack.top()].isLeaf) //Push stack
		{
			level--;
			cellCheck = glm::uvec3(rayEnd) >> level;
			uint32_t child = nodes[stack.top()].childrenOffset + Octree::SegmentOctant(cellCheck);
			stack.push(child);
			continue;
		}

		glm::vec4 nt = nextDist();
		t = nt.w + bias;
		//normal = {nt.x, nt.y, nt.z};
		rayEnd = rayOrigin + dir * t;

	}

	//std::cout << "Checks:" << checks << "\n";

	RayHitData data = {didHit, t, d, normal, (glm::ivec3(cellCheck<<level)*Chunk::CHUNKSIZE) + crd.hitPos, stack.top()};
	return data;
}

ChunkRayData OctreeManager::RaycastChunk(glm::vec3 origin, glm::vec3 dir, size_t chunkIdx)
{
	glm::uvec3 cellCheck = glm::uvec3(origin);// / (unsigned)Chunk::CHUNKSIZE;

	glm::vec3 rayDelta = abs(1.0f/dir);
	glm::ivec3 rayStep = glm::ivec3(sign(dir));
	glm::bvec3 raySign = glm::bvec3(rayStep.x < 0, rayStep.y < 0, rayStep.z < 0);

	glm::vec3 nextT = (glm::vec3(glm::ivec3(cellCheck) + glm::ivec3(glm::not_(raySign))) - origin) * (1.0f/dir);
	float t = 0.0f;

	glm::vec3 sn = glm::normalize(origin - glm::vec3(cellCheck));
	glm::vec3 n = glm::vec3(glm::compMax(sn) == sn.x, glm::compMax(sn) == sn.y, glm::compMax(sn) == sn.z) * glm::sign(sn);

	uint32_t checks = 0;
	while (checks < 64)
	{
		if (chunks[chunkIdx]->Get(cellCheck.x, cellCheck.y, cellCheck.z).type != VoxelType::NONE)
		{
			return { t, n, glm::ivec3(cellCheck)};
		}

		if (nextT.x < nextT.y) {
			if (nextT.x < nextT.z) {
				cellCheck.x += rayStep.x;
				t = nextT.x;
				nextT.x += rayDelta.x;
				n = glm::vec3(1, 0, 0) * -float((dir.x > 0) - (dir.x < 0));
			}
			else {
				cellCheck.z += rayStep.z;
				t = nextT.z;
				nextT.z += rayDelta.z;
				n = glm::vec3(0, 0, 1) * -float((dir.z > 0) - (dir.z < 0));
			}
		}
		else
		{
			if (nextT.y < nextT.z) {
				cellCheck.y += rayStep.y;
				t = nextT.t;
				nextT.y += rayDelta.y;
				n = glm::vec3(0, 1, 0) * -float((dir.y > 0) - (dir.y < 0));
			}
			else {
				cellCheck.z += rayStep.z;
				t = nextT.z;
				nextT.z += rayDelta.z;
				n = glm::vec3(0, 0, 1) * -float((dir.z > 0) - (dir.z < 0));
			}
		}

		if (cellCheck.x >= Chunk::CHUNKSIZE || cellCheck.y >= Chunk::CHUNKSIZE || cellCheck.z >= Chunk::CHUNKSIZE || cellCheck.x < 0 || cellCheck.y < 0 || cellCheck.z < 0)
		{
			//miss
			break;
		}

		checks++;
	}

	return { -1.0f, {}, {} };
}

Physics::RayResult OctreeManager::SphereCast(glm::vec3 offset, float radius, glm::vec3 direction, float maxDist)
{
	std::lock_guard<std::mutex> lock(chunkMutex);
	Physics::RayResult res = {false, INFINITY};
	for (auto& it : chunkIdMap)
	{
		if (it.second >= chunks.size()) continue;
		if (chunks[it.second]->level != 0) continue;

		//AABB box
		Physics::RayResult boxRes = Physics::RayBox({ offset, direction }, { (glm::vec3)(chunks[it.second]->chunkPosition*Chunk::CHUNKSIZE) - radius, glm::vec3(Chunk::CHUNKSIZE+(2*radius)) });
		if (boxRes.hit && boxRes.t <= maxDist)
		{
			Physics::RayResult tempRes = Physics::SphereMesh({ offset - (glm::vec3)(chunks[it.second]->chunkPosition * Chunk::CHUNKSIZE), direction }, radius, collisionMeshes[it.second]);

			if (tempRes.hit && tempRes.t < res.t)
			{
				res = tempRes;
			}
		}
	}

	if (res.t < maxDist) { return res; }

	return { false, 0.0f };
}

void OctreeManager::SetVoxel(glm::ivec3 offset, Voxel voxel)
{
	std::lock_guard<std::mutex> lock(chunkMutex);

	uint64_t maxSize = (1U << octree.getNodes()[0].level) * Chunk::CHUNKSIZE;
	if (glm::any(glm::lessThan(offset, { 0,0,0 })) || glm::any(glm::greaterThanEqual(offset, { maxSize, maxSize , maxSize }))) {return;}

	size_t id = octree.Get(offset / Chunk::CHUNKSIZE);
	OctreeNode& node = octree.getNodes()[id];

	if (chunkIdMap.find(id) == chunkIdMap.end()) { return; }
	Chunk* chunk = GetChunkFromID(id);
	if (!chunk->isLoaded) return;

	glm::ivec3 localOffset = (glm::ivec3(offset) - (glm::ivec3(node.offset)*Chunk::CHUNKSIZE)) >> (int)node.level;

	chunk->Set(localOffset.x, localOffset.y, localOffset.z, voxel);

	if (std::find(chunkMeshQueue.begin(), chunkMeshQueue.end(), id) == chunkMeshQueue.end())
	{
		chunkMeshQueue.push_back(id);
	}
}

Voxel OctreeManager::GetVoxel(glm::ivec3 offset)
{
	std::lock_guard<std::mutex> lock(chunkMutex);

	size_t id = octree.Get(offset / Chunk::CHUNKSIZE);
	OctreeNode& node = octree.getNodes()[id];

	if (chunkIdMap.find(id) == chunkIdMap.end()) { return Voxel{}; }
	Chunk* chunk = GetChunkFromID(id);
	if (!chunk->isLoaded) return Voxel{};

	glm::ivec3 localOffset = (glm::ivec3(offset) - (glm::ivec3(node.offset) * Chunk::CHUNKSIZE)) >> (int)node.level;

	return chunk->Get(localOffset.x, localOffset.y, localOffset.z);
}

void OctreeManager::UpdateChunks()
{
	if (pauseOctreeUpdates)
	{
		return;
	}

	std::vector<uint32_t> createList;
	std::vector<uint32_t> destroyList;

	std::function<void(uint32_t)> createFunc = [&](uint32_t index) {
		auto loc = std::find(destroyList.begin(), destroyList.end(), index);
		if (loc != destroyList.end())
		{
			destroyList.erase(loc);
		}
		createList.push_back(index);
		};

	std::function<void(uint32_t)> destroyFunc = [&](uint32_t index) {
		auto loc = std::find(createList.begin(), createList.end(), index);
		if (loc != createList.end())
		{
			createList.erase(loc);
		}
		destroyList.push_back(index);
		};

	std::stack<int> segmentStack;
	std::stack<uint32_t> indexStack;

	const std::vector<OctreeNode>& nodes = octree.getNodes();

	segmentStack.push(0);
	indexStack.push(0);

	int t = 0;

	float abC = lodC;

	while (t < 10000000) //10M
	{
		t++;

		if (segmentStack.top() > 7 || (indexStack.size() == 1 && indexStack.top() != 0))
		{
			segmentStack.pop();
			indexStack.pop();

			if (segmentStack.empty())
			{
				break;
			}

			segmentStack.top()++;
			indexStack.top()++;
			continue;
		}

		if (nodes[indexStack.top()].isLeaf)
		{
			//For every leaf octant
			const OctreeNode& node = nodes[indexStack.top()];
			glm::uvec3 o = node.offset;

			glm::vec3 centrePoint = (o + (1U << (uint32_t)(node.level - 1)));
			glm::vec3 diff = centrePoint - (savedCameraPosition / 32.0f);
			float dist = glm::length(diff);

			int ideal_lod = lodFunc(dist, abC);

			if (node.level > 0 && node.level > ideal_lod)
			{
				octree.Split(indexStack.top());

				//std::cout << "Split id=" << indexStack.top() << " childOffset=" << nodes[indexStack.top()].childrenOffset << "\n";

				//DeleteChunk(indexStack.top());
				for (int i = 0; i < 8; i++) { CreateChunk(nodes[indexStack.top()].childrenOffset + i); }
				
				continue;
			}

			//Increment Stack
			segmentStack.top()++;
			indexStack.top()++;
		}
		else
		{
			//For every non-leaf octant
			const OctreeNode& node = nodes[indexStack.top()];
			glm::uvec3 o = node.offset;

			glm::vec3 centrePoint = (o + (1U << (uint32_t)(node.level - 1)));
			glm::vec3 diff = centrePoint - (savedCameraPosition / 32.0f);
			float dist = glm::length(diff);

			int ideal_lod = std::min(lodFunc(dist, abC), (int)nodes[0].level);

			//maybe we merge octant 0 before octants 1 2 3 4 meaning they dont iterate!

			if (node.level <= ideal_lod)
			{
				int oco = nodes[indexStack.top()].childrenOffset;
				if (octree.TryMerge(indexStack.top()))
				{
					//std::cout << "TryMerge id=" << indexStack.top() << " childOffset=" << oco << "\n";
					//CreateChunk(indexStack.top());
					for (int i = 0; i < 8; i++) { DeleteChunk(oco + i); }
					continue;
				}
			}

			//Push Stack
			segmentStack.push(0);
			indexStack.push(nodes[indexStack.top()].childrenOffset);
		}
	}

	stats.lastT = t;

	//this doesn't work if multiple splits occur during one update, since it will delete a nothing chunk and create an already deleted semi split
	//fix: check for prexisting index in a queue, delete that
	//problem: popping mid queue ruins the point of a queue, a queue should be exclusively FIFO

	//TODO: keep old chunks until new chunks are finished meshing

	std::lock_guard<std::mutex> lock(chunkMutex);

	for (auto& idx : destroyList)
	{
		DeleteChunk(idx);
	}

	for (auto& idx : createList)
	{
		CreateChunk(idx);
	}

}

void OctreeManager::LoadChunks()
{
	if (chunkLoadQueue.empty()) { return; }

	uint32_t chunkId = chunkLoadQueue.front();
	chunkLoadQueue.pop();

	if (chunkIdMap.find(chunkId) == chunkIdMap.end()) { return; }

	//Load Chunk Here
	//chunks[chunkIdx].Load();

	// 2**7 chunks across each 32 blocks
	// 128 * 32 = 4096 blocks across

	///*

	glm::vec3 centre = glm::vec3(2048, 2048, 2048);
	float radiusSqr = 1024 * 1024;

	Chunk* chunk = GetChunkFromID(chunkId);

	//chunk to world

	glm::vec3 worldPos = chunk->chunkPosition * Chunk::CHUNKSIZE;

	for(int x = 0; x < 32; x++)
		for (int y = 0; y < 32; y++)
			for (int z = 0; z < 32; z++)
			{
				glm::vec3 diff = glm::vec3(glm::ivec3(x, y, z)<<chunk->level) + worldPos - centre;
				float distSqr = glm::length2(diff);
				if (distSqr < radiusSqr) {
					chunk->Set(x, y, z, Voxel{VoxelType::COBBLESTONE});
				}
				else {
					chunk->Set(x, y, z, Voxel{ VoxelType::NONE });
				}
			}
	//*/
	/*

	glm::vec3 centre = glm::vec3(16, 16, 16);
	float radiusSqr = 8 * 8;

	Chunk* chunk = GetChunkFromID(chunkId);

	//chunk to world

	glm::vec3 worldPos = chunk->chunkPosition * Chunk::CHUNKSIZE;

	for (int x = 0; x < 32; x++)
		for (int y = 0; y < 32; y++)
			for (int z = 0; z < 32; z++)
			{
				glm::vec3 diff = glm::vec3(x, y, z) - centre;
				float distSqr = glm::length2(diff);
				if (distSqr < radiusSqr) {
					chunk->Set(x, y, z, Voxel{ VoxelType::COBBLESTONE });
				}
				else {
					chunk->Set(x, y, z, Voxel{ VoxelType::NONE });
				}
			}
	*/
	
	chunk->isLoaded = true;
	chunkMeshQueue.push_back(chunkId);
}

void OctreeManager::MeshChunks()
{
	if (chunkMeshQueue.empty()) { return; }
	
	uint32_t chunkId = chunkMeshQueue.front();
	chunkMeshQueue.pop_front();

	if (chunkIdMap.find(chunkId) == chunkIdMap.end()) { return; }

	ChunkMesh& cm = GetMeshFromID(chunkId);
	Physics::CollisionMesh& colm = GetCollisionMeshFromID(chunkId);

	builder.BuildMesh(GetChunkFromID(chunkId), &cm);
	stats.meshBytes += GetMeshFromID(chunkId).mesh.bytes;

	if (GetChunkFromID(chunkId)->level == 0)
	{
		colm.vertices.reserve(cm.mesh.vertexPositions.size()/3);
		for (size_t i = 0; i < cm.mesh.vertexPositions.size(); i += 3)
		{
			colm.vertices.emplace_back(cm.mesh.vertexPositions[i], cm.mesh.vertexPositions[i + 1], cm.mesh.vertexPositions[i + 2]);
		}

		colm.tris.reserve(cm.mesh.indices.size() / 3);
		for (size_t i = 0; i < cm.mesh.indices.size(); i += 3)
		{
			colm.tris.emplace_back(cm.mesh.indices[i], cm.mesh.indices[i + 1], cm.mesh.indices[i + 2]);
		}

		colm.RecalculateEdges();
	}


	chunkBufferQueue.push(chunkId);
}

void OctreeManager::CreateChunk(uint32_t id)
{

	bool found = chunkIdMap.find(id) != chunkIdMap.end();

	size_t idx = chunks.size();
	//std::cout << "Creating Chunk id=" << id << ", idx=" << idx << " found=" << found << "\n";

	if (found) { return; }
	std::lock_guard<std::mutex> lock(chunkMutex);
	
	chunkIdMap.insert(std::pair<uint32_t, size_t>(id, idx));
	chunks.emplace_back(std::make_unique<Chunk>());
	meshes.emplace_back(ChunkMesh());
	collisionMeshes.emplace_back(Physics::CollisionMesh{});

	meshes[idx].position = octree.getNodes()[id].offset;
	chunks[idx]->chunkPosition = octree.getNodes()[id].offset;
	chunks[idx]->level = octree.getNodes()[id].level;

	chunkLoadQueue.push(id);
}

void OctreeManager::DeleteChunk(uint32_t id)
{
	bool found = chunkIdMap.find(id) != chunkIdMap.end();

	size_t idx = chunkIdMap[id];

	//std::cout << "Deleting Chunk id=" << id << ", idx=" << idx << " found=" << found << "\n";

	if (!found) { return; }
	std::lock_guard<std::mutex> lock(chunkMutex);

	if (idx == 0) {
		throw std::exception();
	}
	
	for (auto& it : chunkIdMap)
	{
		if (it.second > idx)
		{
			//std::cout << "Shifting Chunk id=" << it.first << ", idx=" << it.second << " > " << idx << "\n";
			it.second--;
		}
	}

	chunkIdMap.erase(id);
	chunks.erase(chunks.begin() + idx);
	stats.meshBytes -= meshes[idx].mesh.bytes;
	meshes.erase(meshes.begin() + idx);
}

Chunk* OctreeManager::GetChunkFromID(uint32_t id)
{
	if (chunkIdMap.find(id) == chunkIdMap.end()) { return nullptr; }
	return chunks[chunkIdMap[id]].get();
}

ChunkMesh& OctreeManager::GetMeshFromID(uint32_t id)
{
	if (chunkIdMap.find(id) == chunkIdMap.end()) { throw std::exception(); }
	return meshes[chunkIdMap[id]];
}

Physics::CollisionMesh& OctreeManager::GetCollisionMeshFromID(uint32_t id)
{
	if (chunkIdMap.find(id) == chunkIdMap.end()) { throw std::exception(); }
	return collisionMeshes[chunkIdMap[id]];
}

void OctreeManager::workerFunction()
{
	while (workerRunning)
	{
		{
			std::unique_lock<std::mutex> lock(cameraMutex);
			//cv.wait(lock);
		}

		if (!workerRunning) break;

		//Chunk Pipeline
		UpdateChunks();
		LoadChunks();
		MeshChunks();
	}
}

void ChunkMesh::AddFace(const std::array<GLfloat, 12>& face, const std::array<GLfloat, 8>& texCoords, const glm::vec3& normal, const glm::ivec3& voxelPos)
{
	mesh.texturePositions.insert(mesh.texturePositions.end(), texCoords.begin(), texCoords.end());

	for (int i = 0, index = 0; i < 4; ++i)
	{
		mesh.vertexPositions.push_back(face[index++] + voxelPos.x);
		mesh.vertexPositions.push_back(face[index++] + voxelPos.y);
		mesh.vertexPositions.push_back(face[index++] + voxelPos.z);
		mesh.normals.push_back(normal.x);
		mesh.normals.push_back(normal.y);
		mesh.normals.push_back(normal.z);
	}

	mesh.indices.insert(mesh.indices.end(), { vertexCount, vertexCount + 1, vertexCount + 2, vertexCount, vertexCount + 2, vertexCount + 3 });
	vertexCount += 4;
}
