#pragma once

#include <SDL3/SDL.h>

#include "../imgui/imgui.h"
#include "../imgui/imgui_impl_sdl3.h"
#include "../imgui/imgui_impl_opengl3.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "Render/Shader.h"

#include "State/GameStateWorld.h"

#include <iostream>

class Application
{
public:
	Application();

	void Run();

	static void message_callback(GLenum source, GLenum type, GLuint id, GLenum severity, GLsizei length, const GLchar* message, const void* userParam);

	SDL_Window* GetWindow() { return window; }
	ImGuiIO* GetIO() { return io; }

private:
	SDL_Window* window;
	SDL_GLContext context;
	ImGuiIO* io;

	std::unique_ptr<GameState::GameStateBase> gameState;
};

