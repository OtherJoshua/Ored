#pragma once

#include <SDL3/SDL.h>
#include "../Render/Camera.h"
#include "../Octree/OctreeManager.h"

class Application;

namespace GameState
{
	class GameStateBase
	{
	public:
		GameStateBase(Application* app) { this->app = app; };
		~GameStateBase() = default;

		virtual void Update(double deltaTime) {};
		virtual void Event(SDL_Event event) {};

	protected:
		Application* app;
	};
}
