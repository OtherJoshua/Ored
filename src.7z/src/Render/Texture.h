#pragma once

#include "../../stb_image.h"
#include <string>

#include <glad/glad.h>
#include <GLFW/glfw3.h>


class Texture
{
public:
	Texture(const char* filepath);
	virtual ~Texture();

	int getWidth() const { return width; }
	int getHeight() const { return height; }

	GLuint getId() const { return id; }

protected:
	GLuint id;
	int width, height;

	void LoadTexture(const char* filepath);
};

