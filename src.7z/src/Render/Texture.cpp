#include "Texture.h"

Texture::Texture(const char* filepath)
{
	width = 0;
	height = 0;
	id = 0;

	LoadTexture(filepath);
}

Texture::~Texture()
{
	if (id)
	{
		glDeleteTextures(1, &id);
	}
}

void Texture::LoadTexture(const char* filepath)
{
	int numColCh;
	uint8_t* bytes = stbi_load(filepath, &width, &height, &numColCh, 0);
	
	glGenTextures(1, &id);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, id);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, bytes);

	stbi_image_free(bytes);
	glBindTexture(GL_TEXTURE_2D, 0);
}
