#include "TextureAtlas.h"

TextureAtlas::TextureAtlas(const char* filepath, int countX, int countY)
	: Texture(filepath)
{
	this->countX = countX;
	this->countY = countY;
	this->unitX = 1.0 / countX;
	this->unitY = 1.0 / countY;
}

glm::vec2 TextureAtlas::GetUV(int x, int y) const
{
	return glm::vec2(unitX * x, unitY * y);
}

std::array<GLfloat, 8> TextureAtlas::GetUVArray(int x, int y) const
{
	std::array<GLfloat, 8> uv = {
		unitX * x + unitX, unitY * y + unitY,
		unitX * x + unitX, unitY * y,
		unitX * x, unitY * y,
		unitX * x, unitY * y + unitY

	};
	return uv;
}
