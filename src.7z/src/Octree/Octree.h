#pragma once

#include <cstdint>
#include <glm/glm.hpp>

#include "Chunk.h"
#include <queue>

struct OctreeNode
{
	uint8_t childMask;
	uint8_t isLeaf;

	glm::uvec3 offset;

	uint8_t level;

	uint32_t childrenOffset;
};

const std::array<glm::u8vec3, 8> octreeOffsets = {
	glm::u8vec3(0, 0, 0),
	glm::u8vec3(1, 0, 0),
	glm::u8vec3(0, 1, 0),
	glm::u8vec3(1, 1, 0),
	glm::u8vec3(0, 0, 1),
	glm::u8vec3(1, 0, 1),
	glm::u8vec3(0, 1, 1),
	glm::u8vec3(1, 1, 1),
};

class Octree
{
public:
	Octree();

	size_t Get(const glm::ivec3 position, uint32_t startIndex = 0);  //TODO: check this actually works?
	
	void Split(uint32_t index = 0);

	void ForceMerge(uint32_t nodeIndex);
	bool TryMerge(uint32_t nodeIndex);

	std::vector<OctreeNode>& getNodes() { return nodes; }
	std::queue<uint32_t>& getFreed() { return freedIndices; }

	static uint32_t SegmentOctant(glm::ivec3 localPos);

private:
	uint32_t AddNode(uint8_t level, glm::ivec3 offset);
	std::vector<OctreeNode> nodes;
	std::queue<uint32_t> freedIndices;
};

