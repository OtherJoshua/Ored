#include "Physics.h"

namespace Physics
{
	glm::vec3 ProjectToPlane(glm::vec3 point, glm::vec3 normal)
	{
		float d = glm::dot(point, normal);

		if (glm::abs(d) < EPSILON) {
			return point;
		}

		return point - normal*d;
	}

	RayResult RayTriangle(const Ray& ray, const glm::vec3& v1, const glm::vec3& v2, const glm::vec3& v3)
	{
		glm::vec3 edgeA = v2 - v1;
		glm::vec3 edgeB = v3 - v1;
		glm::vec3 rayCrossEdgeB = glm::cross(ray.direction, edgeB);

		//Test for Parallel
		float pDot = glm::dot(edgeA, rayCrossEdgeB);
		if (pDot < EPSILON && pDot > -EPSILON) { return { false, 0.0f }; }

		float invDot = 1.0f / pDot;
		glm::vec3 s = ray.origin - v1;
		float u = invDot * glm::dot(s, rayCrossEdgeB);

		if ((u < 0 && abs(u) > EPSILON) || (u > 1 && abs(u - 1) > EPSILON)) { return { false, 0.0f }; }

		glm::vec3 sCrossEdgeA = glm::cross(s, edgeA);
		float v = invDot * dot(ray.direction, sCrossEdgeA);

		if ((v < 0 && abs(v) > EPSILON) || (u + v > 1 && abs(u + v - 1) > EPSILON)) { return { false, 0.0f }; }

		float t = invDot * dot(edgeB, sCrossEdgeA);

		if (t > EPSILON) // ray intersection
		{
			return { true, t, glm::cross(edgeA, edgeB)};
		}

		return { false, 0.0f };
	}

	RayResult RayCapsule(const Ray& ray, const Capsule& capsule)
	{
		glm::vec3 AB = capsule.b - capsule.a; // Capsule segment
		glm::vec3 AO = ray.origin - capsule.a; // Vector from capsule start to ray origin
		glm::vec3 V = ray.direction; // Ray direction

		// Project ray onto capsule segment (tCapsule parameter)
		float ab2 = glm::dot(AB, AB);
		float abao = glm::dot(AB, AO);
		float abv = glm::dot(AB, V);

		// Quadratic equation coefficients
		glm::vec3 Q = AO - AB * (abao / ab2);
		glm::vec3 W = V - AB * (abv / ab2);

		float a = glm::dot(W, W);
		float b = 2.0f * glm::dot(Q, W);
		float c = glm::dot(Q, Q) - (capsule.radius * capsule.radius);

		// Solve quadratic equation: at^2 + bt + c = 0
		float discriminant = b * b - 4.0f * a * c;

		if (discriminant < 0) {
			return { false, 0.0f }; // No real roots, no intersection
		}

		// Compute the two intersection times
		float sqrtD = std::sqrt(discriminant);
		float t0 = (-b - sqrtD) / (2.0f * a);
		float t1 = (-b + sqrtD) / (2.0f * a);

		float t = 0.0f;

		// Find the closest valid intersection
		if (t0 > EPSILON) {
			return { true, t0 };
		}
		if (t1 > EPSILON) {
			return { true, t1 };
		}

		return { false, 0.0f }; // No valid intersection within ray range
	}

	RayResult RayBox(const Ray& ray, const Box& box)
	{
		float tNear = -INFINITY;
		float tFar = INFINITY;
		int hitAxis = -1;

		glm::vec3 boxMin = box.pos;
		glm::vec3 boxMax = box.pos + box.size;

		for (int i = 0; i < 3; ++i) { // Iterate over X, Y, Z axes
			if (fabs(ray.direction[i]) < EPSILON) { // Ray is parallel to slab
				if (ray.origin[i] < boxMin[i] || ray.origin[i] > boxMax[i])
					return { false, 0.0f }; // Ray is outside slab
			}
			else {
				float t1 = (boxMin[i] - ray.origin[i]) / ray.direction[i];
				float t2 = (boxMax[i] - ray.origin[i]) / ray.direction[i];

				if (t1 > t2) std::swap(t1, t2); // Ensure t1 is the near intersection

				if (t1 > tNear)
				{
					tNear = t1;
					hitAxis = i;
				}
				tFar = std::min(tFar, t2);

				if (tNear > tFar) return { false, 0.0f }; // Ray misses the box
			}
		}
		if(tFar < 0) return { false, 0.0f }; // True if intersection is in front of the ray

		glm::vec3 hitNormal = glm::vec3(0.0f);
		if (hitAxis != -1) {
			hitNormal[hitAxis] = (ray.origin[hitAxis] < (boxMin[hitAxis] + boxMax[hitAxis]) * 0.5f) ? -1.0f : 1.0f;
		}

		return { true, std::max(tNear, 0.0f), hitNormal};
	}

	RayResult RayMesh(const Ray& ray, const CollisionMesh& mesh)
	{
		RayResult result = {false, INFINITY};
		for (auto& tri : mesh.tris)
		{
			glm::vec3 v1 = mesh.vertices[tri.v1];
			glm::vec3 v2 = mesh.vertices[tri.v2];
			glm::vec3 v3 = mesh.vertices[tri.v3];

			RayResult triResult = RayTriangle(ray, v1, v2, v3);
			if (triResult.hit && triResult.t < result.t)
			{
				result = triResult;
			}
		}

		return result;
	}

	RayResult SphereMesh(const Ray& ray, float radius, const CollisionMesh& mesh)
	{
		RayResult result = { false, INFINITY };
		for (auto& tri : mesh.tris)
		{
			glm::vec3 v1 = mesh.vertices[tri.v1];
			glm::vec3 v2 = mesh.vertices[tri.v2];
			glm::vec3 v3 = mesh.vertices[tri.v3];

			glm::vec3 n = glm::normalize(glm::cross(v2 - v1, v3 - v1));
			v1 += n * radius;
			v2 += n * radius;
			v3 += n * radius;
			
			RayResult triResult = RayTriangle(ray, v1, v2, v3);
			if (triResult.hit && triResult.t < result.t)
			{
				result = { triResult.hit, triResult.t, n };
			}
		}

		
		for (auto& edge : mesh.edges)
		{
			Capsule capsule = { mesh.vertices[edge.v1], mesh.vertices[edge.v2], radius };
			RayResult edgeResult = RayCapsule(ray, capsule);
			if (edgeResult.hit && edgeResult.t < result.t)
			{
				result = edgeResult;
			}
		}
		

		return result;
	}

	void CollisionMesh::RecalculateFaces()
	{
		throw std::exception();

		std::unordered_set<Triangle> faceSet;
		for (int i = 0; i < vertices.size(); i+=3) {
			faceSet.insert({i, i+1, i+2});
		}
		tris = {};
		tris = std::vector<Triangle>(faceSet.begin(), faceSet.end());
	}

	void CollisionMesh::RecalculateEdges()
	{
		std::unordered_set<Edge> edgeSet;
		for (const auto& tri : tris) {
			auto [a, b, c] = tri;
			edgeSet.insert({ a, b });
			edgeSet.insert({ b, c });
			edgeSet.insert({ c, a });
		}
		edges = {};
		edges = std::vector<Edge>(edgeSet.begin(), edgeSet.end());
	}

}

