#pragma once

#include <vector>

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cerrno>

#include <glad/glad.h>
#include <GLFW/glfw3.h>


std::string get_file_contents(const char* filename);

class ShaderInstance
{
public:
	ShaderInstance(const std::string source, const GLenum shaderType);
	~ShaderInstance();

	void Attach(GLuint program) const;

private:
	GLuint instance;
};

class ShaderProgram
{
public:
	ShaderProgram(const ShaderInstance& instance);
	ShaderProgram(const ShaderInstance& instanceA, const ShaderInstance& instanceB);
	~ShaderProgram();

	void Use();
	GLuint getId();
	GLuint ShaderLocation(std::string name);

private:
	GLuint program;
};

