#include "GameStateWorld.h"

#include "../Application.h"

GameState::GameStateWorld::GameStateWorld(Application* app)
	: GameStateBase(app)
{
	this->camera = std::make_unique<Camera>(1280, 720);
	this->manager = std::make_unique<OctreeManager>();

	this->mouseCaptured = false;
	this->voxelTypeSelect = VoxelType::NONE;

	this->shader = std::make_shared<ShaderProgram>(
		ShaderInstance(get_file_contents("res/default.vert"), GL_VERTEX_SHADER),
		ShaderInstance(get_file_contents("res/default.frag"), GL_FRAGMENT_SHADER)
	);

	this->player = new Player(this);
	this->player->position = glm::vec3(2048, 3080, 2048);
	this->t = 0;
}

GameState::GameStateWorld::~GameStateWorld()
{
	delete player;
}

void GameState::GameStateWorld::Update(double deltaTime)
{
	t++;
	
	auto start = std::chrono::high_resolution_clock::now();

	if (player != nullptr)
	{
		HandlePlayer(deltaTime);
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli> duration = end - start;
	physicsTime = duration.count();

	manager->UpdateCameraPosition(player->position);

	shader->Use();
	camera->Matrix(player->position, player->orientation, 0.1f, 10000.0f, shader->getId());

	manager->BufferMeshes();
	manager->Render(camera.get(), shader.get());

	if (manager->getStats().chunkLoadQueueSize == 0) { t = 1001; }

	dt = deltaTime;
	GUI();
}

void GameState::GameStateWorld::Event(SDL_Event event)
{
	switch (event.type)
	{
	case SDL_EVENT_KEY_DOWN:
		if (event.key.scancode == SDL_SCANCODE_ESCAPE && !event.key.repeat) {
			mouseCaptured = !mouseCaptured;
			SDL_SetWindowRelativeMouseMode(app->GetWindow(), mouseCaptured);
		}
		break;

	case SDL_EVENT_WINDOW_RESIZED:
		glViewport(0, 0, event.window.data1, event.window.data2);
		camera->width = event.window.data1;
		camera->height = event.window.data2;

		break;

	default:
		break;
	}

	if (player != nullptr) { player->Event(event); }
}

void GameState::GameStateWorld::HandlePlayer(double deltaTime)
{
	if (!app->GetIO()->WantCaptureMouse)
	{
		player->Update(deltaTime);
	}
}

void GameState::GameStateWorld::GUI()
{
	ImGui::Begin("Debug Panel");
	ImGui::DragFloat3("Position", &player->position.x, 1.0f, 0.0f, 0.0f, "%.1f");
	ImGui::SliderFloat("Speed", &player->speed, 1.0f, 500.0f);
	ImGui::SliderFloat("FOV", &camera->FOV, 1, 180);
	ImGui::SliderFloat("LOD C", &manager->lodC, 0.0f, 10.0f);
	ImGui::Text("deltaTime: %f", dt);
	ImGui::Text("physicsTime (ms): %f", physicsTime);
	ImGui::Checkbox("Pause Octree", &manager->pauseOctreeUpdates);

	const char* voxelNames[VoxelType::MAX_VOXEL_TYPE];
	for (int i = 0; i < VoxelType::MAX_VOXEL_TYPE; i++) {
		voxelNames[i] = voxelData[i].name.c_str();
	}
	ImGui::ListBox("VoxelType", (int*)&voxelTypeSelect, voxelNames, VoxelType::MAX_VOXEL_TYPE);

	if (ImGui::CollapsingHeader("Data")) {
		ImGui::Text("Chunks Loaded: %i", manager->getStats().chunkCount);
		ImGui::Text("Chunk Arrays: %i", Chunk::chunk_memory_unit);
		ImGui::Text("lastT: %u", manager->getStats().lastT);
		ImGui::Text("Octree Size: %i", manager->getStats().octreeSize);
		ImGui::Text("Nodes Used: %i", manager->getStats().octreeSize - manager->getStats().octreeFreed);
	}

	int mb = 1024 * 1024;
	if (ImGui::CollapsingHeader("Memory")) {
		ImGui::Text("Chunk Memory (MiB): %i", Chunk::chunk_memory_unit * Chunk::CHUNKSIZE * Chunk::CHUNKSIZE * Chunk::CHUNKSIZE * sizeof(Voxel) / mb);
		ImGui::Text("Mesh Memory (MiB): %i", manager->getStats().meshBytes / mb);
		ImGui::Text("Octree Memory (MiB): %i", manager->getStats().octreeSize * sizeof(OctreeNode) / mb);
	}

	if (ImGui::CollapsingHeader("Queues")) {
		ImGui::Text("Load Queue: %i", manager->getStats().chunkLoadQueueSize);
		ImGui::Text("Mesh Queue: %i", manager->getStats().chunkMeshQueueSize);
		ImGui::Text("Buff Queue: %i", manager->getStats().chunkBufferQueueSize);
	}

	ImGui::End();
}


