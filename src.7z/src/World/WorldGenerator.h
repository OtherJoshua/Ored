#pragma once

/*

#include "Chunk.h"
#include <array>

#include "../../noise/OpenSimplexNoise.h"


class WorldGenerator
{
public:
	WorldGenerator() = default;

	void GenerateChunk(Chunk& chunk);
	void GenerateHeightmap();

private:
	Chunk* chunkPtr;

	std::array<int, Chunk::CHUNK_SIZE * Chunk::CHUNK_SIZE> heightMap;

	OpenSimplexNoise::Noise noise = OpenSimplexNoise::Noise(127);

};

*/