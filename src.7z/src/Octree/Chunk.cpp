#include "Chunk.h"

int Chunk::chunk_memory_unit = 0;

#include <iostream>

Chunk::Chunk()
{
	data = std::make_unique<Voxel[]>(CHUNKSIZE * CHUNKSIZE * CHUNKSIZE);
	isLoaded = false;
	chunkPosition = { 0,0,0 };
	level = 0;
	chunk_memory_unit++;

	//std::cout << "Voxel[] Create" << std::endl;
}

Chunk::~Chunk()
{
	chunk_memory_unit--;
	//std::cout << "Voxel[] Delete" << std::endl;
}

void Chunk::Set(uint32_t x, uint32_t y, uint32_t z, Voxel voxel)
{
	data[(size_t)x + (size_t)y * CHUNKSIZE + (size_t)z * CHUNKSIZE * CHUNKSIZE] = voxel;
}

Voxel& Chunk::Get(uint32_t x, uint32_t y, uint32_t z)
{
	return data[(size_t)x + (size_t)y * CHUNKSIZE + (size_t)z * CHUNKSIZE * CHUNKSIZE];
}
