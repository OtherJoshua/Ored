#include "WorldGenerator.h"

/*

void WorldGenerator::GenerateChunk(Chunk& chunk)
{
	chunkPtr = &chunk;

	int waterLevel = 64;

	GenerateHeightmap();

	for (int z = 0; z < Chunk::CHUNK_SIZE; z++)
		for (int x = 0; x < Chunk::CHUNK_SIZE; x++)
			for (int y = 0; y < Chunk::CHUNK_SIZE; y++)
			{
				int globalY = y + chunkPtr->getGlobalPosition().y*Chunk::CHUNK_SIZE;
				VoxelType type = VoxelType::NONE;

				int height = heightMap[x + z * Chunk::CHUNK_SIZE];

				if (globalY < height - 3) { type = VoxelType::STONE; }
				else if (globalY < height) { type = VoxelType::DIRT; }
				else if (globalY == height) {
					if (globalY <= waterLevel) { type = VoxelType::SAND; }
					else { type = VoxelType::GRASS; }
				}
				else if (globalY < waterLevel) { type = VoxelType::WATER; }

				if (type != VoxelType::NONE)
				{
					chunkPtr->SetVoxel(x, y, z, { type });
				}
					
			}
}

void WorldGenerator::GenerateHeightmap()
{
	glm::vec3 chunkPos = chunkPtr->getGlobalPosition();

	int xOff = chunkPos.x * Chunk::CHUNK_SIZE;
	int zOff = chunkPos.z * Chunk::CHUNK_SIZE;

	float seaLevel = 64;
	float surfaceVariance = 16;

	float period = 120.0f;
	int octaves = 5;

	for (int x = 0; x < Chunk::CHUNK_SIZE; x++)
		for (int z = 0; z < Chunk::CHUNK_SIZE; z++)
		{
			float n = 0;
			for (int i = 0; i < octaves; i++)
			{
				n += noise.eval((xOff + x) / period * pow(2, i), (zOff + z) / period * pow(2, i)) * pow(0.5, i);
			}

			heightMap[x + z * Chunk::CHUNK_SIZE] = seaLevel + (surfaceVariance * n);
		}
}
*/