#include "Model.h"

#include <iostream>

Model::Model(const Mesh& mesh)
{
	buffers = {};
	AddData(mesh);
}

Model::~Model()
{
	DeleteData();
}

void Model::AddData(const Mesh& mesh)
{
	GenVAO();
	AddVBO(3, mesh.vertexPositions);
	AddVBO(2, mesh.texturePositions);
	AddVBO(3, mesh.normals);
	AddEBO(mesh.indices);
}

void Model::DeleteData()
{
	if (vao)
	{
		glDeleteVertexArrays(1, &vao);
	}
	if (buffers.size() > 0)
	{
		glDeleteBuffers(static_cast<GLsizei>(buffers.size()), buffers.data());
	}
	buffers.clear();

	vboCount = 0;
	vao = 0;
	indexCount = 0;
}

void Model::GenVAO()
{
	if (vao != 0) {
		DeleteData();
	}

	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);
}

void Model::AddEBO(const std::vector<GLuint>& indices)
{
	indexCount = indices.size();
	GLuint ebo;
	glGenBuffers(1, &ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), indices.data(), GL_STATIC_DRAW);

	buffers.push_back(ebo);
}

void Model::AddVBO(int dimensions, const std::vector<GLfloat>& data)
{
	if (data.empty())
	{
		//std::cout << "Tried to add null data to a buffer." << std::endl;
		return;
	}

	GLuint vbo;
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);

	glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(GLfloat), data.data(), GL_STATIC_DRAW);

	glVertexAttribPointer(vboCount, dimensions, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(vboCount++);

	buffers.push_back(vbo);
}

void Model::BindVAO()
{
	glBindVertexArray(vao);
}

int Model::getIndicesCount() const
{
	return indexCount;
}

bool Model::isBuffered() const
{
	return vao != 0;
}

void Model::Draw() const
{
	if (indexCount != 0)
	{
		glBindVertexArray(vao);
		glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);
	}
}
